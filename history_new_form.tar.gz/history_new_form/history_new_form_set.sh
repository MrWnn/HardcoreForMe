#!/bin/bash

work_path=$(cd `dirname $0`;pwd)
bash_conf=/etc/bashrc
user_profile=/etc/profile
bash_add=${work_path}/conf/bash_add
profile_add=${work_path}/conf/profile_add
test ! -e "${bash_conf}" && echo ${bash_conf} 不存在 && exit
test ! -e "${user_profile}" && echo ${user_profile} 不存在 && exit

ip=`/sbin/ifconfig |grep inet |grep 192|awk '{print $2}'|awk -F: '{print $2}'`

test "${ip}" == "" && echo ip 获取失败 && exit 1
check_bashrc=`cat ${bash_conf}|grep yunwei_command_history_restore|wc -l`
check_profile=`cat ${user_profile}|grep yunwei_command_history_restore|wc -l`

if test "${check_bashrc}" -lt 1
then
	sed -i "s/IP_TO_CHANGE/${ip}/g" ${bash_add}
	cat ${bash_add} >> "${bash_conf}"
	source "${bash_conf}"
else
	echo 命令行历史存储配置已存在
fi

test "${check_profile}" -ge 1 && echo 命令行历史存储配置已存在 && exit 1
sed -i "s/IP_TO_CHANGE/${ip}/g" ${profile_add}
cat ${profile_add}  >> "${user_profile}" 
source "${user_profile}"

rm -vf ${bash_add}
rm -fv ${profile_add}
